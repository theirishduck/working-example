// User defined code goes here. Code valid for Articulate 2
var emailObject = document.createElement("a"),
	subtitlesObject = document.createElement("a"),
	slideNumber = document.createElement("p"),
	progressBarObject = document.createElement("div"),
	controlNode = document.getElementById("control-progress"),
	nextButtonNode = document.getElementById("control-next"),
	refreshButtonNode = document.getElementsByClassName("icon restart"),
	playButtonNode = document.getElementsByClassName("icon play"),
	pauseButtonNode = document.getElementsByClassName("pausebtn progress-bar-button"),
	menuNode = undefined,//document.getElementById("topbar"),
	player = GetPlayer(),
	API = window.top.API ? window.top.API : null,
	userStatus = null,//API.LMSGetValue('cmi.core.lesson_status') ? API.LMSGetValue('cmi.core.lesson_status') : null,
	entryStatus = null,//API.LMSGetValue('cmi.core.entry') ? API.LMSGetValue('cmi.core.entry') : null,
	blinkInterval,
	enterFrame,
	checkCurrentStatusInterval,
	checkInitalStatusInterval,
	checkFinalStatusInterval,
	slideNumberNode,
	nextBlinking = false,
	toggle = false,
	isOnPause = false,
	prevSlide = 0,
	completePercentage,
	j = 0,
	k = 0,
	subTitleNode,
	//totalTime = 10,
	subTitleNode,
	//update subject and email body
	mailto = 'onlinelearning@gadventures.com',
	emailsubject = 'Engagement',
	emailbody = 'What was the slide number of the issue?'+'%0A'+'What was the issue?',
	pdfFileName = 'Engagement_Notes.pdf';


function init(){
	//appending nodes to progress bar
	controlNode.appendChild(emailObject);
	controlNode.appendChild(slideNumber);
	controlNode.appendChild(subtitlesObject);
	controlNode.appendChild(progressBarObject);
	//adds ID names and descriptions to nodes
	slideNumber.title = 'Current slide number'
	subtitlesObject.id = 'subtitlesIcon';
	subtitlesObject.title = 'Subtiles';
	emailObject.id = 'emailIcon';
	emailObject.title = 'Send email';
	progressBarObject.id = 'courseProgressBar';
	refreshButtonNode[0].title = 'Restart';
	playButtonNode[0].title = 'Play';
	pauseButtonNode[0].title = 'Pause';
	//adds links to hiperlinks
	emailObject.href = 'mailto:'+mailto+'?subject='+emailsubject+'&body='+emailbody;
	subtitlesButtonNode = document.getElementById("subtitlesIcon");
	//toggle for subtitles
	subtitlesButtonNode.onclick = function(e){
		toggle = !toggle
		player.SetVar('toggle',String(toggle));
		toggle ? subtitlesObject.style.opacity = 0.5 : subtitlesObject.style.opacity = 1;

	}
	//offest function calls
	checkCurrentStatusInterval = setInterval(checkCurrentStatus, 10);// enterframe listener that triggers UI
	checkInitalStatusInterval = setInterval(checkInitialStatus, 1000);// checks if user has seen module
	subtitlesObject.style.opacity = 1;
}

//selects subtitles divs from slides base on height
function retrieveSubtitles(collection){
	for(var elem in collection){
		if(collection[elem].style.height === '74'+'px' || collection[elem].style.height === '75'+'px'){
			return collection[elem];
		}
	}
};
//checks if subtiles are on/off
//checks if user has paused for more than 50 secs
function checkCurrentStatus(){
	var slideText;
	var arrFromList;
	var bolt = false;
	var subtitle1;

	progressBarObject.title = 'Course progress bar';// + Math.floor(totalTime - totalTime * completePercentage)+'m : '+( ((totalTime - totalTime * completePercentage) * 60) % 60) + 's';

	if(slideText !== prevSlide){

		slideText = Number(player['slideIndex'] - 4);
		arrFromList = Array.prototype.slice.call(document.getElementsByClassName("itemgroup"));
		//selects subtitle nodes from slides
		if (arrFromList.length > 0){
				if(retrieveSubtitles(arrFromList) !== undefined){
					subTitleNode = retrieveSubtitles(arrFromList);
					toggle ? subTitleNode.style.display = 'block' : subTitleNode.style.display = 'none';
				}
			}
			prevSlide = slideText;
	}
	
	if(player.progressBar.lastProgressPercent === 1){
		(player.currentSlide().title.slice(0,4) !== 'inte') ? controlNode.childNodes[3].childNodes[1].childNodes[0].style.visibility = 'visible' : controlNode.childNodes[3].childNodes[1].childNodes[0].style.visibility = 'hidden';
		if(j > 50){
			if (player.currentSlide().title.slice(0,4) !== 'inte'){
				fadeInOut(nextButtonNode);
			}
			j = 0;
		}
		j++;
	}
	
	//make play button blink if pause if longer than 50
	if(player.lastPaused && player.progressBar.lastProgressPercent !== 1){
		if(k > 50){
			if(playButtonNode[0] !== null){
				fadeInOut(playButtonNode[0]);
			} 
			k = 0;
		}
		k++;
	}
}

//builds fade-in/fade-out animation
function fadeInOut(element){

	if(element !== null){
		if(element.classList.contains("animationFadeOut")){
			element.classList.remove("animationFadeOut");
			element.classList.add("animationFadeIn");
		}else{
			element.classList.remove("animationFadeIn");
			element.classList.add("animationFadeOut");
		}
	}
}

// builds initial status user
function checkInitialStatus(){

	if(API){
		userStatus =  API.LMSGetValue('cmi.core.lesson_status'); // "passed”, “completed”, “failed”, “incomplete”, “browsed”, “not attempted”
		entryStatus =  API.LMSGetValue('cmi.core.entry'); // "resume", "ab-initio"
	}

	// check if user needs to see instructions slide
	if(entryStatus === 'resume'){
		player.SetVar('seenIt','true');
	}else if(entryStatus === 'ab-initio' ) {
		player.SetVar('seenIt','false');
	}

	if(userStatus === 'passed' || userStatus === 'completed') menuNode.style.visibility = "visible";

	clearInterval(checkInitalStatusInterval);
}

//builds the progress status of the user
function checkFinalStatus(){
	var countViewedSlides = 0,
	slidesViewedObject = player.listSlidesViewedComplete || {},
	i = 1,
	totalModuleSlides = player["totalViewSlides"];

	if(API){
		userStatus =  API.LMSGetValue('cmi.core.lesson_status'); // "passed”, “completed”, “failed”, “incomplete”, “browsed”, “not attempted”
		entryStatus =  API.LMSGetValue('cmi.core.entry'); // "resume", "ab-initio"
	}

	for(var prop in slidesViewedObject){
		if(slidesViewedObject[prop] == true){
			countViewedSlides += i;
		}
	}

	// check if user completed all slides
	if(countViewedSlides === totalModuleSlides){
		player.SetVar('seenAllSlides','true');
		menuNode.style.visibility = "visible";
		progressBarObject.style.backgroundPosition = "-225px 0px";
		
			if (API){
				API.LMSSetValue('cmi.core.lesson_status','completed');
				API.LMSCommit("");
				//API.LMSFinish("");			
			}
		}
	clearInterval(checkFinalStatusInterval);
}

function userProgress(progressPercentage){
	if(progressPercentage < 0.2){
		progressBarObject.style.backgroundPosition = "0px 0px";
	}else if(progressPercentage < 0.4){
		progressBarObject.style.backgroundPosition = "-45px 0px";
	}
	else if(progressPercentage < 0.6){
		progressBarObject.style.backgroundPosition = "-90px 0px";
	}
	else if(progressPercentage < 0.8){
		progressBarObject.style.backgroundPosition = "-135px 0px";
		
	}else if(progressPercentage < 1){
		progressBarObject.style.backgroundPosition = "-180px 0px";
	}
}

function nextHandler(){
	checkFinalStatusInterval = setInterval(checkFinalStatus, 1000);
	completePercentage = Number(Number( Number(player.currentSlidesViewed) / Number(player.totalViewSlides) ).toFixed(2)) + 1/player["totalViewSlides"];
	userProgress(completePercentage);
}

nextButtonNode.addEventListener('click',nextHandler);


function createPDF(){
	//player = GetPlayer(),
	console.log('createPDF');
	var doc = new jsPDF(),
		paragraph_width = 360,
		paragraph_distance = 13,//13
		startParagraph = 35,//33
		distance_from_title = 5,//5
		times = 1,
		questionsAndTitles = [
			{title:'Performance Excellence - ENGAGEMENT'},
			{header:"Here are the responses you provided for the Engagement at G activities on " + (Date().slice(0,16))+"Please bring this PDF with you to your next 1 on 1 with your manager so that you can discuss your responses and see if there is anything that you would add or change."},// so that you can discuss your responses and see if there’s anything that you would add or change."},
			{subtitle:'How am I feeling today?',
			answer:"spirits"},
			{subtitle:'My definition of Engagement',
			answer:'TextEntry3'},
			{subtitle:'My ideas about improving Engagement',
			answer:'TextEntry2'}
		];
	//traverses course vars
	questionsAndTitles.forEach(function(obj){
		for(var prop in obj){
			writeText(obj[prop], prop);
		}
	});
	//writes vars and titles
	function writeText(text, type){
		
		doc.addFont('helvetica');
		doc.setFont('helvetica');
		
		switch(type){
			case 'title' :
				doc.setFillColor(119, 130, 143);
				doc.rect(0, 0, 1700, 50 , 'F');	
				doc.setFontSize(24);
				doc.setTextColor(250, 250, 250);
				doc.setFontStyle('bold');
				doc.text(22, paragraph_distance * 1.4, text);
			break;
			case 'header':
				doc.setFontSize(11);
				doc.setTextColor(250, 250, 250);
				doc.setFontStyle('normal');
				doc.text(21, 30, doc.splitTextToSize(text, paragraph_width));
			break;
			case 'subtitle' :
				doc.setFontSize(11);
				doc.setTextColor(0, 0, 0);
				doc.setFontStyle('normal');
				doc.text(10, startParagraph + (paragraph_distance  * times), doc.splitTextToSize(text, paragraph_width));
			break;
			case  'answer' :
				doc.setFontSize(9);
				doc.setTextColor(60, 60, 60);
				doc.setFontStyle('normal');
				doc.text(10, ((startParagraph + distance_from_title) + (paragraph_distance * (times - 1))), doc.splitTextToSize(player.GetVar(text), paragraph_width));
		}

		times++;
	}

	doc.save(pdfFileName);
}


//External call from course
function ExecuteScript(strId){
	createPDF();
}

init();